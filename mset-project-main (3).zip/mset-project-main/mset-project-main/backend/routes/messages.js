const express = require('express');
const fs = require('fs');
const path = require('path');
const auth = require('../authMiddleware');
const router = express.Router();

const dbPath = path.join(__dirname, '..', 'db.json');

// Helper functions
const readDb = () => JSON.parse(fs.readFileSync(dbPath));
const writeDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

// GET /api/messages/inbox
//
router.get('/inbox', auth, (req, res) => {
  try {
    const db = readDb();
    const myId = req.user.id;
    const threads = {};

    const myMessages = db.messages.filter(m => m.toUserId === myId || m.fromUserId === myId);
    
    for (const msg of myMessages) {
      const otherUserId = msg.fromUserId === myId ? msg.toUserId : msg.fromUserId;
      const key = `${msg.listingId}_${otherUserId}`;
      if (!threads[key] || msg.createdAt > threads[key].lastAt) {
        threads[key] = {
          listingId: msg.listingId,
          withUserId: otherUserId,
          withUser: db.users.find(u => u.id === otherUserId) || { name: 'Unknown' },
          lastText: msg.text,
          lastAt: msg.createdAt,
          unread: 0
        };
      }
      if (msg.toUserId === myId && !msg.read) {
        threads[key].unread = (threads[key].unread || 0) + 1;
      }
    }
    const inbox = Object.values(threads).sort((a, b) => b.lastAt - a.lastAt);
    res.json(inbox);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/messages/thread
//
router.get('/thread', auth, (req, res) => {
  try {
    const { withUserId, listingId } = req.query;
    const myId = req.user.id;
    const db = readDb();
    const msgs = db.messages.filter(m => 
      m.listingId === listingId &&
      ((m.fromUserId === myId && m.toUserId === withUserId) || (m.fromUserId === withUserId && m.toUserId === myId))
    ).sort((a, b) => a.createdAt - b.createdAt);
    res.json(msgs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/messages
//
router.post('/', auth, (req, res) => {
  try {
    const { toUserId, listingId, text } = req.body;
    const db = readDb();
    const newMsg = {
      id: `msg-${Date.now()}`,
      fromUserId: req.user.id,
      toUserId,
      listingId,
      text,
      read: false,
      createdAt: Date.now()
    };
    db.messages.push(newMsg);
    writeDb(db);
    res.status(201).json(newMsg);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/messages/mark-read
//
router.post('/mark-read', auth, (req, res) => {
  try {
    const { withUserId, listingId } = req.body;
    const myId = req.user.id;
    const db = readDb();
    db.messages.forEach(msg => {
      if (msg.listingId === listingId && msg.fromUserId === withUserId && msg.toUserId === myId) {
        msg.read = true;
      }
    });
    writeDb(db);
    res.status(200).json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;