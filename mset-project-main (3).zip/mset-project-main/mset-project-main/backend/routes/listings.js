const express = require('express');
const fs = require('fs');
const path = require('path');
const auth = require('../authMiddleware');
const router = express.Router();

const dbPath = path.join(__dirname, '..', 'db.json');

// Helper functions
const readDb = () => JSON.parse(fs.readFileSync(dbPath));
const writeDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

// GET /api/listings
//
router.get('/', (req, res) => {
  try {
    const db = readDb();
    // Your frontend expects the seller's name and email, not just the ID
    const listingsWithSeller = db.listings.map(listing => {
      const seller = db.users.find(u => u.id === listing.seller_id) || { name: 'Unknown', email: 'unknown@example.com' };
      return { ...listing, seller: seller.name, email: seller.email };
    });
    res.json(listingsWithSeller.sort((a, b) => b.createdAt - a.createdAt)); // Send newest first
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/listings
//
router.post('/', auth, (req, res) => {
  try {
    const { title, category, condition, price, description, image } = req.body;
    const db = readDb();
    const newListing = {
      id: `listing-${Date.now()}`,
      title, category, condition, price: Number(price), description, image: image || null,
      seller_id: req.user.id, // from auth middleware
      createdAt: Date.now()
    };
    db.listings.push(newListing);
    writeDb(db);
    res.status(201).json(newListing);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/listings/:id
//
router.put('/:id', auth, (req, res) => {
  try {
    const db = readDb();
    const { title, category, condition, price, description, image } = req.body;
    const index = db.listings.findIndex(l => l.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Listing not found' });
    
    // Check ownership
    if (db.listings[index].seller_id !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const updatedListing = { ...db.listings[index], title, category, condition, price: Number(price), description };
    if (image) updatedListing.image = image; // Only update image if a new one was sent

    db.listings[index] = updatedListing;
    writeDb(db);
    res.json(updatedListing);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE /api/listings/:id
//
router.delete('/:id', auth, (req, res) => {
  try {
    const db = readDb();
    const listing = db.listings.find(l => l.id === req.params.id);
    if (!listing) return res.status(404).json({ error: 'Listing not found' });

    // Check ownership
    if (listing.seller_id !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    db.listings = db.listings.filter(l => l.id !== req.params.id);
    writeDb(db);
    res.status(204).send(); // 204 = No Content (success)
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;