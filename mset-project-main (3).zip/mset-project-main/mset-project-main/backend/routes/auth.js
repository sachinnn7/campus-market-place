const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const dbPath = path.join(__dirname, '..', 'db.json');
const JWT_SECRET = 'change-this-secret'; // From your README

// Helper functions to read/write to the JSON file
const readDb = () => JSON.parse(fs.readFileSync(dbPath));
const writeDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

// POST /api/auth/register
//
router.post('/register', (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }
    const db = readDb();
    if (db.users.find(u => u.email === email)) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const id = (db.users.length + 1).toString();
    const hashedPassword = bcrypt.hashSync(password, 10);
    const newUser = { id, name, email, password: hashedPassword };
    db.users.push(newUser);
    writeDb(db);

    const userPayload = { id: newUser.id, name: newUser.name, email: newUser.email };
    const token = jwt.sign(userPayload, JWT_SECRET, { expiresIn: '1d' });
    res.status(201).json({ token, user: userPayload });

  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/auth/login
//
router.post('/login', (req, res) => {
  try {
    const { email, password } = req.body;
    const db = readDb();
    const user = db.users.find(u => u.email === email);
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const userPayload = { id: user.id, name: user.name, email: user.email };
    const token = jwt.sign(userPayload, JWT_SECRET, { expiresIn: '1d' });
    res.status(200).json({ token, user: userPayload });

  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;