const express = require('express');
const cors = require('cors');

// Import your routes (we will create these next)
const authRoutes = require('./routes/auth');
const listingRoutes = require('./routes/listings');
const messageRoutes = require('./routes/messages');

const app = express();
const PORT = 4000; // Your app.js expects this port

// Middleware
app.use(cors()); // Allow requests from your frontend
app.use(express.json({ limit: '10mb' })); // Allow reading JSON bodies (and large image data)

// API Routes
// Your app.js expects all routes to start with /api
app.use('/api/auth', authRoutes);
app.use('/api/listings', listingRoutes);
app.use('/api/messages', messageRoutes);

// Start the server
app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});